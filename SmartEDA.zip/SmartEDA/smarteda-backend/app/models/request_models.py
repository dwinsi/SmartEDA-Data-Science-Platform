"""
Request models for async API endpoints.
"""

from pydantic import BaseModel, Field
from typing import Any, Dict


class AnalysisRequest(BaseModel):
    """Request model for async dataset analysis."""

    dataset_id: str = Field(..., description="Unique dataset identifier")
    file_path: str = Field(..., description="Path to the dataset file")
    full_analysis: bool = Field(
        default=True, description="Whether to perform full analysis"
    )


class TrainingRequest(BaseModel):
    """Request model for async model training."""

    dataset_id: str = Field(..., description="Unique dataset identifier")
    file_path: str = Field(..., description="Path to the dataset file")
    target_column: str = Field(..., description="Name of the target column")
    model_type: str = Field(
        default="auto",
        description="Type of model (auto, classification, regression)",
    )
    test_size: float = Field(
        default=0.2, description="Proportion of data for testing"
    )


class ReportRequest(BaseModel):
    """Request model for async report generation."""

    dataset_id: str = Field(..., description="Unique dataset identifier")
    analysis_results: Dict[str, Any] = Field(
        ..., description="Analysis results to include in report"
    )
    report_type: str = Field(
        default="comprehensive", description="Type of report to generate"
    )


class SimilaritySearchRequest(BaseModel):
    """Request model for vector database similarity search."""

    file_path: str = Field(..., description="Path to the query dataset file")
    top_k: int = Field(
        default=5, description="Number of similar datasets to return"
    )
