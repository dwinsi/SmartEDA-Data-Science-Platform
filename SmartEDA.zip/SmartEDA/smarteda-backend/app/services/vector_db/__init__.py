"""
Vector Database initialization module.
"""

from .vector_service import vector_db_service

__all__ = ['vector_db_service']
