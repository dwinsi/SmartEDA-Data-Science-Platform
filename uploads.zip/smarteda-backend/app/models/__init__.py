"""Database models for SmartEDA Platform."""
