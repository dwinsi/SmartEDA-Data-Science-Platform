"""
Response models for async API endpoints.
"""

from pydantic import BaseModel, Field
from typing import Any, Dict, Optional


class TaskResponse(BaseModel):
    """Response model for task creation."""

    task_id: str = Field(..., description="Unique task identifier")
    status: str = Field(..., description="Task status")
    message: str = Field(..., description="Status message")


class TaskStatusResponse(BaseModel):
    """Response model for task status queries."""

    task_id: str = Field(..., description="Unique task identifier")
    status: str = Field(..., description="Current task status")
    message: str = Field(..., description="Status message")
    progress: Optional[Dict[str, Any]] = Field(
        None, description="Task progress information"
    )
    result: Optional[Dict[str, Any]] = Field(
        None, description="Task result if completed"
    )
    error: Optional[str] = Field(
        None, description="Error message if task failed"
    )
