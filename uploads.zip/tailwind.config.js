/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
    "./App.tsx",
    "./components/**/*.{js,ts,jsx,tsx}",
    "./utils/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        'inter': ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      colors: {
        blue: {
          50: '#eff6ff',
          100: '#dbeafe',
          200: '#bfdbfe',
          300: '#93c5fd',
          400: '#a8dadc', // Custom SmartEDA blue
          500: '#3b82f6',
          600: '#2563eb',
          700: '#1d4ed8',
          800: '#1e40af',
          900: '#1e3a8a',
        },
        green: {
          50: '#f0fdf4',
          100: '#dcfce7',
          200: '#bbf7d0',
          300: '#86efac',
          400: '#a0d6b4', // Custom SmartEDA green
          500: '#22c55e',
          600: '#16a34a',
          700: '#15803d',
          800: '#166534',
          900: '#14532d',
        },
        },
        colors: {
          gradient1: '#f8f4f4',
          gradient2: '#d5d8d7',
          gradient3: '#a8a1a1',
          gradient4: '#208fe5',
          gradient5: '#0e6937',
          gradient6: '#0a5536',
        },
      container: {
        center: true,
        padding: {
          DEFAULT: '1rem',
          sm: '2rem',
          lg: '4rem',
          xl: '5rem',
          '2xl': '6rem',
        },
      },
      fontSize: {
        'xs': '0.75rem',    // 12px
        'sm': '0.875rem',   // 14px
        'base': '1rem',     // 14px (base)
        'lg': '1.125rem',   // 16px
        'xl': '1.25rem',    // 18px
        '2xl': '1.5rem',    // 21px
        '3xl': '1.875rem',  // 26px
        '4xl': '2.25rem',   // 32px
        '5xl': '3rem',      // 42px
        '6xl': '3.75rem',   // 53px
      },
    },
  },
  plugins: [],
}